#ifndef _DEFINICIONES_H
#define _DEFINICIONES_H
 


typedef enum
{
	MSG_NADIE,
	MSG_AUTOS,
	MSG_VIAS,
}Destinos;

typedef enum
{
	EVT_NINGUNO,
     EVT_VEHICULOS,
     EVT_FINALIZAR
}Eventos;


#endif
