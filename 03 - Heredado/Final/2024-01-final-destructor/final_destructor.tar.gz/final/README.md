## Compilación

```
make
```

## Ejecución

Ejecutar en cualquier orden:

```
./destructor
./guerreros
```
