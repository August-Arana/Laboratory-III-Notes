#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "aleatorios.h"
#include "colas.h"
#include "memoria.h"
#include "defs.h"
#include "thread.h"

/**
 * Sincroniza el arranque de los procesos
 */
void sincronizar_arranque(int *id_memoria_sync, char *sync) {
    /* Sincronizar los procesos para empezar al mismo tiempo */
    sync = (char *) crear_memoria(sizeof(char) * PROCESOS_SIZE, id_memoria_sync, CLAVE_IPC);
    sync[1] = 1;
    printf("Esperando por destructor");
    while (!sync[0]) {
        sleep(1);
        printf(".");
        fflush(stdout);
    }
    printf("\n - Arrancando el proceso\n");
    fflush(stdout);
}

int main(int argc, char *argv[]) {
    int id_memoria_sync;
    char *sync = NULL;
    int id_cola_mensajes;
    t_thread *jugadores;
    int i;
    pthread_t *hilos;
    s_numero *numeros_aleatorios;

    inicializar_semilla_random();

    /* Cola de mensajes */
    id_cola_mensajes = creo_id_cola_mensajes(CLAVE_IPC);
    sincronizar_arranque(&id_memoria_sync, sync);

    /* Hilos */
    hilos = (pthread_t *) malloc(sizeof(pthread_t) * JUGADORES_SIZE);

    /* Inicializar los datos de los jugadores */
    jugadores = (t_thread *) malloc(sizeof(t_thread) * JUGADORES_SIZE);
    numeros_aleatorios = generar_vector_aleatorio_acotado(JUGADORES_SIZE, JUGADOR_NRO_MIN, JUGADOR_NRO_MAX);
    for (i = 0; i < JUGADORES_SIZE; i++) {
        jugadores[i].id_jugador = i + 1;
        jugadores[i].id_destinatario = i + 2;
        jugadores[i].numero_jugador = numeros_aleatorios[i].numero;
        memset(jugadores[i].nombre, 0, sizeof(char) * BUFFER_SIZE);
        sprintf(jugadores[i].nombre, "Guerrero %d", i + 1);
        jugadores[i].id_cola_mensajes = id_cola_mensajes;
        jugadores[i].hundido = FALSE;
    }

    /* Correr threads y esperarlos */
    for (i = 0; i < JUGADORES_SIZE; i++) {
        pthread_create(&hilos[i], NULL, thread_func, (void *) &jugadores[i]);
    }
    for (i = 0; i < JUGADORES_SIZE; i++) {
        pthread_join(hilos[i], NULL);
    }

    /* Liberar recursos */
    free(numeros_aleatorios);
    free(jugadores);
    free(hilos);
    liberar_memoria(sync, id_memoria_sync);

    return (0);
}
