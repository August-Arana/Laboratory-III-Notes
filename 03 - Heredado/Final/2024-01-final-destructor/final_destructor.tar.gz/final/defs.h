#ifndef DEFS_H
#define DEFS_H

#include <pthread.h>

#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define BUFFER_SIZE 100

#define DEBUG 0

#define ROJO 0
#define VERDE 1

#define RUTA_IPC "/tmp"
#define CLAVE_IPC 34

#define LARGO_DESCRIPCION 100
#define CANT_SEMAFORO 1

#define DESTRUCTOR_NRO_MIN 1
#define DESTRUCTOR_NRO_MAX 1000
#define JUGADOR_NRO_MIN 1
#define JUGADOR_NRO_MAX 100

#define PROCESOS_SIZE 2
#define JUGADORES_SIZE 3
#define DESTRUCTOR "Destructor"
#define JUGADOR_1 "Guerrero 1"
#define JUGADOR_2 "Guerrero 2"
#define JUGADOR_3 "Guerrero 3"

#define TURNO_TIME 100

typedef enum {
    MSG_NINGUNO = 0,
    MSG_DESTRUCTOR = 1,
    MSG_GUERRERO_1 = 2,
    MSG_GUERRERO_2 = 3,
    MSG_GUERRERO_3 = 4
} t_destinos;

typedef enum {
    EVT_TURNO,
    EVT_TIRO,
    EVT_HUNDIDO,
    EVT_AGUA,
    EVT_FIN
} t_eventos;

typedef struct {
    char nombre[BUFFER_SIZE];
    int is_hundido;
} t_jugador;

typedef struct {
    int id_jugador;
    int id_destinatario;
    int id_cola_mensajes;
    int numero_jugador;
    char nombre[BUFFER_SIZE];
    int hundido;
} t_thread;


#endif
