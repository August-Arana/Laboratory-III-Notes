#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "defs.h"
#include "aleatorios.h"
#include "thread.h"
#include "colas.h"

void* thread_func(void* arg) {
    t_mensaje msg;
    t_thread *jugador = (t_thread *) arg;
    int is_running = TRUE;
    int numero;
    char snumero[BUFFER_SIZE];

    /* Limpiar memoria */
    memset(snumero, 0, sizeof(char) * BUFFER_SIZE);

    printf("%s arrancando con el numero %d\n", jugador->nombre, jugador->id_jugador);

    while (is_running) {
        if (recibir_mensaje(jugador->id_cola_mensajes, jugador->id_destinatario, &msg) == -1) {
            perror("Error recibiendo mensaje");
            continue;
        }

        if (msg.evento == EVT_TURNO) {
            memset(snumero, 0, sizeof(char) * BUFFER_SIZE);
            numero = generar_int_acotado(DESTRUCTOR_NRO_MIN, DESTRUCTOR_NRO_MAX);
            sprintf(snumero, "%d", numero);

            enviar_mensaje(jugador->id_cola_mensajes, MSG_DESTRUCTOR, jugador->id_destinatario, EVT_TIRO, snumero);
        }

        if (msg.evento == EVT_TIRO) {
            numero = atoi(msg.mensaje);
            if (numero == jugador->numero_jugador) {
                /* Le dieron al jugador, perdio el jugador */
                printf("%s hundido, finalizando\n", jugador->nombre);
                is_running = FALSE;
                enviar_mensaje(jugador->id_cola_mensajes, MSG_DESTRUCTOR, jugador->id_destinatario, EVT_HUNDIDO, "");
            } else {
                /* printf("%s agua\n", jugador->nombre); */
                enviar_mensaje(jugador->id_cola_mensajes, MSG_DESTRUCTOR, jugador->id_destinatario, EVT_AGUA, "");
            }
        }

        if (msg.evento == EVT_FIN) {
            is_running = FALSE;
            printf("Jugador %d finalizando\n", jugador->id_jugador);
        }
    }

    pthread_exit(0);
}
