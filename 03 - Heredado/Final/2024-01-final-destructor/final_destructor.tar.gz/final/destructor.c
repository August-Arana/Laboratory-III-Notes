#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "aleatorios.h"
#include "colas.h"
#include "defs.h"
#include "memoria.h"

/**
 * Sincroniza el arranque de los procesos
 */
void sincronizar_arranque(int *id_memoria_sync, char *sync) {
    /* Sincronizar los procesos para empezar al mismo tiempo */
    sync = (char *) crear_memoria(sizeof(char) * PROCESOS_SIZE, id_memoria_sync, CLAVE_IPC);
    sync[0] = 1;
    printf("Esperando por guerreros");
    while (!sync[1]) {
        sleep(1);
        printf(".");
        fflush(stdout);
    }
    printf(" - Arrancando el proceso\n");
    fflush(stdout);
}

int main(int argc, char *argv[]) {
    int id_memoria_sync;
    char *sync = NULL;
    t_jugador equipos[JUGADORES_SIZE];
    int i, id_cola_mensajes;
    t_mensaje msg;
    int is_running = TRUE;
    int id_turno = 0;
    int numero;
    char snumero[BUFFER_SIZE];
    int numero_destructor;
    int jugadores_hundidos = 0;
    int destinatario;

    inicializar_semilla_random();

    /* Limpiar memoria */
    memset(snumero, 0, sizeof(char) * BUFFER_SIZE);

    /* Cola de mensajes */
    id_cola_mensajes = creo_id_cola_mensajes(CLAVE_IPC);
    borrar_mensajes(id_cola_mensajes);

    sincronizar_arranque(&id_memoria_sync, sync);

    /* Inicializar jugadores */
    for (i = 0; i < JUGADORES_SIZE; i++) {
        memset(equipos[i].nombre, 0, sizeof(char) * BUFFER_SIZE);
        equipos[i].is_hundido = FALSE;
        sprintf(equipos[i].nombre, "Jugador %d", i + 1);
    }

    /* Inicializar destructor */
    numero_destructor = generar_int_acotado(DESTRUCTOR_NRO_MIN, DESTRUCTOR_NRO_MAX);

    printf("Guerrero comenzando con el numero %d\n", numero_destructor);

    while (is_running) {
        /* Turno 0 es del guerrero, cualquier otro turno es de los jugadores */
        if (id_turno == 0) {
            numero = generar_int_acotado(JUGADOR_NRO_MIN, JUGADOR_NRO_MAX);
            memset(snumero, 0, sizeof(char) * BUFFER_SIZE);
            sprintf(snumero, "%d", numero);
            for (i = 0; i < JUGADORES_SIZE; i++) {
                if (!equipos[i].is_hundido) {
                    destinatario = i + 2;
                    enviar_mensaje(id_cola_mensajes, destinatario, MSG_DESTRUCTOR, EVT_TIRO, snumero);
                    recibir_mensaje(id_cola_mensajes, MSG_DESTRUCTOR, &msg);
                    if (msg.evento == EVT_HUNDIDO) {
                        equipos[i].is_hundido = TRUE;
                        jugadores_hundidos++;
                        printf("Destructor %d hundido. Numero enviado: %d\n", i + 1, numero);
                    } else {
                        printf("Destructor %d agua. Numero enviado: %d\n", i + 1, numero);
                    }
                }
            }

            /* Verificar si todos los jugadores estan hundidos */
            if (jugadores_hundidos == JUGADORES_SIZE) {
                printf("Todos los jugadores hundidos. Destructor gana el partido\n");
                is_running = FALSE;
            }
        } else {
            destinatario = id_turno + 1;
            enviar_mensaje(id_cola_mensajes, destinatario, MSG_DESTRUCTOR, EVT_TURNO, "");
            recibir_mensaje(id_cola_mensajes, MSG_DESTRUCTOR, &msg);
            numero = atoi(msg.mensaje);
            if (numero == numero_destructor) {
                /* Le dieron al desctructor, perdio el destructor */
                printf("El jugador %d le dio al destructor. Numero recibido %d. Jugadores ganan el partido\n", msg.remitente, numero);
                is_running = FALSE;
            } else {
                printf("El jugador %d erro el tiro al destructor. Numero recibido %d\n", msg.remitente, numero);
            }
        }

        /* Los turnos van de 0 a JUGADORES_SIZE, caso contrario vuelve a comenzar los turnos.
         * El turno 0 es del destructore, el 1 del jugador 1, el 2 del jugador 2, etc. */
        id_turno++;
        while(equipos[id_turno - 1].is_hundido) { id_turno++; }
        if (id_turno > JUGADORES_SIZE) {
            id_turno = 0;
        }

        usleep(TURNO_TIME);

        fflush(stdout);
    }

    for (i = 0; i < JUGADORES_SIZE; i++) {
        enviar_mensaje(id_cola_mensajes, i + 2, MSG_DESTRUCTOR, EVT_FIN, "");
    }

    /* Eliminar memoria compartida */
    liberar_memoria(sync, id_memoria_sync);
    borrar_cola_de_mensajes(id_cola_mensajes);

    return (0);
}
