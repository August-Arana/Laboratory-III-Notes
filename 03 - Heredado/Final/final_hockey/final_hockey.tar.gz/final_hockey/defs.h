#ifndef DEFS_H
#define DEFS_H

#include <pthread.h>

#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define BUFFER_SIZE 100

#define DEBUG 1

#define ROJO 0
#define VERDE 1

#define RUTA_IPC "/tmp"
#define CLAVE_IPC 34

#define LARGO_DESCRIPCION 100
#define CANT_SEMAFORO 1

#define EQUIPOS_SIZE 2
#define JUGADORES_SIZE 5
#define EQUIPO_1 "Equipo 1"
#define EQUIPO_2 "Equipo 2"
#define JUGADOR_1 "Arquero"
#define JUGADOR_2 "Defensor 1"
#define JUGADOR_3 "Defensor 2"
#define JUGADOR_4 "Delantero 1"
#define JUGADOR_5 "Delantero 2"
#define META 5

#define PRODUCTOR_DESDE 50000
#define PRODUCTOR_HASTA 80000

typedef enum {
    MSG_NINGUNO = 0,
    MSG_EQUIPO_1_JUGADOR_1 = 1,
    MSG_EQUIPO_1_JUGADOR_2 = 2,
    MSG_EQUIPO_1_JUGADOR_3 = 3,
    MSG_EQUIPO_1_JUGADOR_4 = 4,
    MSG_EQUIPO_1_JUGADOR_5 = 5,
    MSG_EQUIPO_2_JUGADOR_1 = 6,
    MSG_EQUIPO_2_JUGADOR_2 = 7,
    MSG_EQUIPO_2_JUGADOR_3 = 8,
    MSG_EQUIPO_2_JUGADOR_4 = 9,
    MSG_EQUIPO_2_JUGADOR_5 = 10,
    MSG_ARBITRO = 11
} t_destinos;

typedef enum {
    EVT_0_PUNTOS = 0,
    EVT_1_PUNTOS = 1,
    EVT_2_PUNTOS = 2,
    EVT_TIRAR,
    EVT_FIN
} t_eventos;

typedef struct {
    char nombre[BUFFER_SIZE];
    int puntos;
} t_equipo;

typedef struct {
    int id_equipo;
    int id_jugador;
    int id_cola_mensajes;
    char nombre[BUFFER_SIZE];
    int puntos;
} t_thread;


#endif
