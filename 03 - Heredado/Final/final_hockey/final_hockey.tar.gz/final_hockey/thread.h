#ifndef THREAD_H
#define THREAD_H

/**
 * Corre los threads
 * @param arg Argumento para el thread
 * @return
 */
void* thread_func(void* arg);

#endif
