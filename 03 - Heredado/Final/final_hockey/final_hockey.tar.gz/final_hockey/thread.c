#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include "defs.h"
#include "aleatorios.h"
#include "thread.h"
#include "colas.h"

void* thread_func(void* arg) {
    t_mensaje msg;
    t_thread *jugador = (t_thread *) arg;
    int is_running = TRUE;
    int is_gol;

    printf("Equipo %d jugador %s arrancando\n", jugador->id_equipo, jugador->nombre);

    while (is_running) {
        if (recibir_mensaje(jugador->id_cola_mensajes, jugador->id_jugador, &msg) == -1) {
            perror("Error recibiendo mensaje");
            continue;
        }

        if (msg.evento == EVT_FIN) {
            is_running = FALSE;
            printf("Equipo %d jugador %s finalizado\n", jugador->id_equipo, jugador->nombre);
            break;
        }

        if (msg.evento == EVT_TIRAR) {
            is_gol = generar_int_acotado(0, 1);
            if (jugador->id_jugador % 5 == 1 && is_gol) {
                printf("Gol del arquero, vale 2 puntos\n");
                is_gol++;
            } else if (is_gol) {
                printf("Gol, vale 1 punto\n");
            } else {
                printf("Tiro errado\n");
            }

            enviar_mensaje(jugador->id_cola_mensajes, MSG_ARBITRO, jugador->id_jugador, is_gol, "");
        }
    }

    pthread_exit(0);
}
