#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "aleatorios.h"
#include "colas.h"
#include "defs.h"
#include "memoria.h"

/**
 * Sincroniza el arranque de los procesos
 */
void sincronizar_arranque(int *id_memoria_sync, char *sync) {
    /* Sincronizar los procesos para empezar al mismo tiempo */
    sync = (char *) crear_memoria(sizeof(char) * 3, id_memoria_sync, CLAVE_IPC);
    sync[0] = 1;
    printf("Esperando por equipos");
    while (!sync[1] || !sync[2]) {
        sleep(1);
        printf(".");
        fflush(stdout);
    }
    printf(" - Arrancando el proceso\n");
    fflush(stdout);
}

void informar_ganador(t_equipo equipos[]) {
    if (equipos[0].puntos == 5) {
        printf("Gano el equipo 1\n");
    } else {
        printf("Gano el equipo 2\n");
    }
    printf("Resultado: %s %d - %s %d\n", equipos[0].nombre, equipos[0].puntos, equipos[1].nombre, equipos[1].puntos);
}

int main(int argc, char *argv[]) {
    int id_memoria_sync;
    char *sync = NULL;
    t_equipo equipos[EQUIPOS_SIZE];
    int i, j, id_cola_mensajes;
    t_mensaje msg;
    int is_running = 2;
    int id_equipo_turno;
    int id_equipo_1_turno = 5;
    int id_equipo_2_turno = 5;
    long destinatario;

    /* Cola de mensajes */
    id_cola_mensajes = creo_id_cola_mensajes(CLAVE_IPC);
    borrar_mensajes(id_cola_mensajes);

    sincronizar_arranque(&id_memoria_sync, sync);

    /* Inicializar jugadores */
    for (i = 0; i < EQUIPOS_SIZE; i++) {
        memset(equipos[i].nombre, 0, sizeof(char) * BUFFER_SIZE);
        equipos[i].puntos = 0;
    }
    strcpy(equipos[0].nombre, EQUIPO_1);
    strcpy(equipos[1].nombre, EQUIPO_2);

    id_equipo_turno = generar_int_acotado(0, EQUIPOS_SIZE - 1);
    printf("El equipo que comienza es: %s\n", equipos[id_equipo_turno].nombre);

    while (is_running) {
        /* Le avisamos al jugador que le toca que puede patear */
        msg.remitente = MSG_ARBITRO;
        if (id_equipo_turno == 0) {
            destinatario = id_equipo_1_turno;
        } else {
            destinatario = id_equipo_2_turno + 5;
        }
        enviar_mensaje(id_cola_mensajes, destinatario, MSG_ARBITRO, EVT_TIRAR, "");

        /* Recibir el mensaje del jugador */
        if (recibir_mensaje(id_cola_mensajes, MSG_ARBITRO, &msg) == -1) {
            perror("Error recibiendo mensaje");
            continue;
        }
        if (id_equipo_turno == 0) {
            printf("Equipo 1: ");
        } else {
            printf("Equipo 2: ");
        }
        if (destinatario == 1 || destinatario == 6) {
            printf("Arquero tiro al arco.");
        } else if (destinatario == 2 || destinatario == 7) {
            printf("Defensor 1 tiro al arco.");
        } else if (destinatario == 3 || destinatario == 8) {
            printf("Defensor 2 tiro al arco.");
        } else if (destinatario == 4 || destinatario == 9) {
            printf("Delantero 1 tiro al arco.");
        } else if (destinatario == 5 || destinatario == 10) {
            printf("Delantero 2 tiro al arco.");
        }
        if (msg.evento == EVT_0_PUNTOS) {
            /* 0 puntos, informar en pantalla */
            printf(" Tiro errado.\n");
        } else if (msg.evento == EVT_1_PUNTOS) {
            /* 1 punto, informar en pantalla */
            printf("Gol!. Vale 1 punto.\n");
            equipos[id_equipo_turno].puntos++;
        } else if (msg.evento == EVT_2_PUNTOS) {
            /* 2 puntos, informar en pantalla */
            printf("Gol!. Vale 2 puntos.\n");
            equipos[id_equipo_turno].puntos+=2;
        }

        printf("Puntaje: %s %d - %s %d\n", equipos[0].nombre, equipos[0].puntos, equipos[1].nombre, equipos[1].puntos);

        for (i = 0; i < EQUIPOS_SIZE; i++) {
            if (equipos[i].puntos >= META) {
                is_running = FALSE;
            }
        }

        /* Cambiar el turno del jugador del equipo que acaba de patear */
        if (id_equipo_turno == 0) {
            id_equipo_1_turno--;
            if (id_equipo_1_turno == 0) {
                id_equipo_1_turno = 5;
            }
        } else {
            id_equipo_2_turno--;
            if (id_equipo_2_turno == 1) {
                id_equipo_2_turno = 5;
            }
        }

        /* Cambiar el turno del equipo, podria ser aleatorio para mas diversion */
        if (id_equipo_turno == 0) {
            id_equipo_turno = 1;
        } else {
            id_equipo_turno = 0;
        }

        fflush(stdout);
    }

    for (i = 0; i < EQUIPOS_SIZE; i++) {
        for (j = 0; j < JUGADORES_SIZE; j++) {
            if (i == 0) {
                destinatario = j + 1;
            } else {
                destinatario = j + 6;
            }
            enviar_mensaje(id_cola_mensajes, destinatario, MSG_ARBITRO, EVT_FIN, "");
        }
    }

    informar_ganador(equipos);

    /* Eliminar memoria compartida */
    liberar_memoria(sync, id_memoria_sync);
    borrar_cola_de_mensajes(id_cola_mensajes);

    return (0);
}
