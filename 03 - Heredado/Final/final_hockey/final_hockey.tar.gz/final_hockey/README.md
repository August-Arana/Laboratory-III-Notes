## Compilación

```
make
```

## Ejecución

Ejecutar en cualquier orden:

```
./arbitro
./equipo 1
./equipo 2
```
