#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "aleatorios.h"
#include "colas.h"
#include "memoria.h"
#include "defs.h"
#include "thread.h"

/**
 * Sincroniza el arranque de los procesos
 */
void sincronizar_arranque(int *id_memoria_sync, char *sync, int id_equipo) {
    /* Sincronizar los procesos para empezar al mismo tiempo */
    sync = (char *) crear_memoria(sizeof(char) * 3, id_memoria_sync, CLAVE_IPC);
    sync[id_equipo] = 1;
    printf("Equipo %d Esperando por el arbitro y el otro equipo", id_equipo);
    if (id_equipo == 1) {
        while (!sync[0] || !sync[2]) {
            sleep(1);
            printf(".");
            fflush(stdout);
        }
    } else {
        while (!sync[0] || !sync[1]) {
            sleep(1);
            printf(".");
            fflush(stdout);
        }
    }
    printf(" - Arrancando el proceso\n");
    fflush(stdout);
}

int obtener_id_equipo(int argc, char *argv[]) {
    int id_equipo;
    if (argc != 2) {
        printf("Uso: %s <id_jugador>\n", argv[0]);
        exit(1);
    }
    id_equipo = atoi(argv[1]);
    if (id_equipo < 1 || id_equipo > EQUIPOS_SIZE) {
        printf("El id del jugador debe estar entre 1 y %d\n", EQUIPOS_SIZE);
        exit(1);
    }
    return id_equipo;
}


int main(int argc, char *argv[]) {
    int id_memoria_sync;
    int id_equipo;
    char *sync = NULL;
    int id_cola_mensajes;
    t_thread *jugadores;
    int i;
    pthread_mutex_t mutex;
    pthread_t *hilos;

    id_equipo = obtener_id_equipo(argc, argv);

    inicializar_semilla_random();

    /* Cola de mensajes */
    id_cola_mensajes = creo_id_cola_mensajes(CLAVE_IPC);
    sincronizar_arranque(&id_memoria_sync, sync, id_equipo);

    /* Hilos */
    hilos = (pthread_t *) malloc(sizeof(pthread_t) * JUGADORES_SIZE);

    /* Mutex */
    pthread_mutex_init(&mutex, NULL);

    /* Inicializar los datos de los jugadores */
    jugadores = (t_thread *) malloc(sizeof(t_thread) * JUGADORES_SIZE);
    for (i = 0; i < JUGADORES_SIZE; i++) {
        jugadores[i].id_equipo = id_equipo;
        if (id_equipo == 1) {
            jugadores[i].id_jugador = i + 1;
        } else {
            jugadores[i].id_jugador = i + 6;
        }
        memset(jugadores[i].nombre, 0, sizeof(char) * BUFFER_SIZE);
        jugadores[i].id_cola_mensajes = id_cola_mensajes;
        jugadores[i].puntos = 0;
    }
    strcpy(jugadores[0].nombre, JUGADOR_1);
    strcpy(jugadores[1].nombre, JUGADOR_2);
    strcpy(jugadores[2].nombre, JUGADOR_3);
    strcpy(jugadores[3].nombre, JUGADOR_4);
    strcpy(jugadores[4].nombre, JUGADOR_5);

    /* Correr threads y esperarlos */
    for (i = 0; i < JUGADORES_SIZE; i++) {
        pthread_create(&hilos[i], NULL, thread_func, (void *) &jugadores[i]);
    }
    for (i = 0; i < JUGADORES_SIZE; i++) {
        pthread_join(hilos[i], NULL);
    }

    /* Liberar recursos */
    free(jugadores);
    free(hilos);
    liberar_memoria(sync, id_memoria_sync);

    return (0);
}
