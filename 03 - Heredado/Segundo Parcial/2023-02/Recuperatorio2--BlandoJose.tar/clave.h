#ifndef _CLAVE_H
#define _CLAVE_H

#include <sys/ipc.h>

#define CLAVE_BASE 33

key_t creo_clave(int r_clave);

#endif

