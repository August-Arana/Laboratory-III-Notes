#ifndef _ALEATORIOS_H
#define _ALEATORIOS_H

int generar_aleatorio(int desde, int hasta);
void inicializar_aleatorios();

#endif

