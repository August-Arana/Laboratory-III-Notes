## Compilación

```
make
```

## Ejecución

Ejecutar en cualquier orden:

```
./cancha
./jugadores
```
