#ifndef KARTING_H
#define KARTING_H

void mostrar_menu(void);
int menu_principal(void);
void ingresar_producto(t_producto *producto);
int main(int argc, char *argv[]);

#endif
