#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "defs.h"
#include "archivos.h"
#include "aleatorios.h"
#include "semaforos.h"
#include "equipo.h"

void imprimir_uso(void) {
    printf("Usage: ./equipo id_equipo\n");
    printf("id_equipo: 1 si es Argentina, 2 si es Japón\n");
}

int inicializar_configuracion(int argc, char *argv[]) {
    int id;
    /* Verificar parametros de entrada */
    if (argc != 2) {
        imprimir_uso();
        exit(-1);
    } else {
        id = atoi(argv[1]);
        if (id < 1 || id > 3) {
            imprimir_uso();
            exit(-2);
        }
    }

    return id;
}

int verificar_partido_finalizado(char *contenido_archivo) {
    return strstr(contenido_archivo, "FINALIZADA") != NULL;
}

int verificar_turno_de_escribir(char *contenido_archivo, int id_equipo, int turno_actual) {
    char linea_a_buscar[10], karting_a_buscar[10];
    char *posicion_turno, *encontrado;

    sprintf(linea_a_buscar, "TURNO %d", turno_actual);
    sprintf(karting_a_buscar, "EQUIPO %d", id_equipo);
    posicion_turno = strstr(contenido_archivo, linea_a_buscar);
    if (posicion_turno) {
        encontrado = strstr(posicion_turno, karting_a_buscar);
        return encontrado == NULL;
    }
    return FALSE;
}

int main(int argc, char *argv[]) {
    FILE *archivo;
    int id_equipo, semaforo;
    char contenido_archivo[ARCHIVO_SIZE];
    int es_partido_finalizado = FALSE, es_turno_de_escribir = FALSE;
    int turno_actual = 1;
    int remate;

    id_equipo = inicializar_configuracion(argc, argv);

    inicializar_semilla_random();

    archivo = abrir_archivo(ARCHIVO, "r+");

    semaforo = crear_semaforo(CLAVE_IPC, ARCHIVO);

    while(!es_partido_finalizado) {
        esperar_semaforo(semaforo);

        posicionar_archivo_al_principio(archivo);
        leer_archivo(archivo, &contenido_archivo, ARCHIVO_SIZE);

        es_partido_finalizado = verificar_partido_finalizado(contenido_archivo);

        if (!es_partido_finalizado) {
            es_turno_de_escribir = verificar_turno_de_escribir(contenido_archivo, id_equipo, turno_actual);

            if (es_turno_de_escribir) {
                remate = generar_int_acotado(1, 2);
                sprintf(contenido_archivo, "EQUIPO %d: %d\n", id_equipo, remate);
                posicionar_archivo_al_final(archivo);
                escribir_archivo(archivo, contenido_archivo, strlen(contenido_archivo));

                printf("Turno %d remató %d\n", turno_actual, remate);

                turno_actual++;
            }

            levantar_semaforo(semaforo);

            usleep(generar_int_acotado(INTERVALO_PRODUCTOR_DESDE, INTERVALO_PRODUCTOR_HASTA));
        } else {
            printf("Partido finalizado\n");
            levantar_semaforo(semaforo);
        }
    };

    return 0;
}
