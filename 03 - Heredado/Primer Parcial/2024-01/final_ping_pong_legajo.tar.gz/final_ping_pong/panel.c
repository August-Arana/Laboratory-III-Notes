#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "defs.h"
#include "aleatorios.h"
#include "archivos.h"
#include "semaforos.h"
#include "panel.h"

void imprimir_uso(void) {
    printf("Usage: ./panel puntaje_maximo\n");
}

int inicializar_configuracion(int argc, char *argv[]) {
    int puntaje_maximo;
    
    /* Verificar parametros de entrada */
    if (argc != 2) {
        imprimir_uso();
        exit(-1);
    }

    puntaje_maximo = atoi(argv[1]);

    return(puntaje_maximo);
}

char *buscar_turno_actual(char *contenido, int turno_actual) {
    char buscar[10];
    sprintf(buscar, "TURNO %d", turno_actual);
    return strstr(contenido, buscar);
}

int verificar_escribieron_equipos(char *contenido) {
    int i;
    char buscar[10];
    for (i = 1; i <= EQUIPOS_SIZE; i++) {
        sprintf(buscar, "EQUIPO %d", i);
        if (strstr(contenido, buscar) == NULL) {
            return FALSE;
        }
    }
    return TRUE;
}

void parsear_jugadas(char *contenido, int *jugadas) {
    int i;
    char *posicion;
    char *posicion_metros;
    char metros_str[10];
    char buscar[10];
    for (i = 1; i <= EQUIPOS_SIZE; i++) {
        sprintf(buscar, "EQUIPO %d", i);
        posicion = strstr(contenido, buscar);
        posicion_metros = strstr(posicion, ": ") + 2; /* Posicionarlo despues del : y espacion en blanco */
        strncpy(metros_str, posicion_metros, 1); /* La jugada puede ser 1 o 2 */
        jugadas[i - 1] = atoi(metros_str);
    }
}

void mostrar_estado_partido(int *puntaje, int *jugada_actual, int turno_actual) {
    printf("Turno actual: %d\n", turno_actual);

    if (jugada_actual[0] == 1) {
        printf("Argentina hizo remate dentro, tanto de Argentina.\n");
    } else if (jugada_actual[0] == 2) {
        printf("Argentina hizo remate afuera, tanto de Japón.\n");
    }

    if (jugada_actual[1] == 1) {
        printf("Japón hizo remate dentro, tanto de Japón.\n");
    } else if (jugada_actual[1] == 2) {
        printf("Japón hizo remate afuera, tanto de Argentina.\n");
    }

    printf("Argentina: %d - Japón %d\n\n", puntaje[0], puntaje[1]);
}

/* En caso de empate agrega un punto a un equipo aleatorio */
void ganador_aleatorio_en_empate(int *puntaje) {
    if (puntaje[0] == puntaje[1]) {
        if (generar_int_acotado(0, 1) == 0) {
            printf("Agregando punto extra aleatorio a Argentina\n");
            puntaje[0]++;
        } else {
            printf("Agregando punto extra aleatorio a Japón\n");
            puntaje[1]++;
        }
    }
}

void mostrar_resultado_final(int *jugadas, int turno_actual) {
    printf("PARTIDO FINALIZADO EN EL TURNO %d\n", turno_actual);
    printf("Argentina %d - Japón %d\n", jugadas[0], jugadas[1]);
    if (jugadas[0] > jugadas[1]) {
        printf("Ganador: Argentina\n");
    } else {
        printf("Ganador: Japón\n");
    }
}

int main(int argc, char *argv[]) {
    FILE *archivo;
    int semaforo;
    int es_partido_finalizado = FALSE;
    char contenido_archivo[ARCHIVO_SIZE];
    int turno_actual = 1;
    char *posicion_turno_actual;
    int puntaje[EQUIPOS_SIZE] = {0, 0};
    int jugada_actual[EQUIPOS_SIZE];
    char contenido_nuevo[50];
    int i;
    int puntaje_maximo;

    puntaje_maximo = inicializar_configuracion(argc, argv);

    inicializar_semilla_random();

    /* Creamos el archivo para dirigir el partido y solo escribimos el TURNO 1 */
    archivo = abrir_archivo(ARCHIVO, "w");
    escribir_archivo(archivo, "TURNO 1\n", strlen("TURNO 1\n"));
    cerrar_archivo(archivo);

    /* Ahora abrimos el archivo en modo r+ para leerlo y agregar texto si fuese necesario */
    archivo = abrir_archivo(ARCHIVO, "r+");

    /* Creamos un solo semaforo */
    semaforo = crear_semaforo(CLAVE_IPC, ARCHIVO);
    inicializar_semaforo(semaforo, VERDE);

    while (!es_partido_finalizado) {
        esperar_semaforo(semaforo);

        posicionar_archivo_al_principio(archivo);
        leer_archivo(archivo, &contenido_archivo, ARCHIVO_SIZE);

        /* Procesamos la informacion */
        posicion_turno_actual = buscar_turno_actual(contenido_archivo, turno_actual);
        if (verificar_escribieron_equipos(posicion_turno_actual)) {
            /* Parsear los metros */
            parsear_jugadas(posicion_turno_actual, jugada_actual);


            /* Calculamos el puntaje
             * Si un equipo hizo remate 1, fue tanto, se suma 1 al puntaje del equipo
             * Si un equiop hizo remate 2, fue fuera, se suma 1 al puntaje del equipo contrario
             */
            if (jugada_actual[0] == 1) {
                puntaje[0]++;
            } else if (jugada_actual[0] == 2) {
                puntaje[1]++;
            }
            if (jugada_actual[1] == 1) {
                puntaje[1]++;
            } else if (jugada_actual[1] == 2) {
                puntaje[0]++;
            }

            /* Verificamos si el partido finalizo */
            for (i = 0; i < EQUIPOS_SIZE; i++) {
                if (puntaje[i] >= puntaje_maximo) es_partido_finalizado = TRUE;
            }

            mostrar_estado_partido(puntaje, jugada_actual, turno_actual);

            if (!es_partido_finalizado) {
                posicionar_archivo_al_final(archivo);
                sprintf(contenido_nuevo, "TURNO %d\n", turno_actual + 1);
                escribir_archivo(archivo, contenido_nuevo, strlen(contenido_nuevo));

                turno_actual++;
            } else {
                sprintf(contenido_nuevo, "FINALIZADA\n");
                posicionar_archivo_al_final(archivo);
                escribir_archivo(archivo, contenido_nuevo, strlen(contenido_nuevo));
            }
        }

        levantar_semaforo(semaforo);

        usleep(INTERVALO_CONSUMIDOR);
    }

    ganador_aleatorio_en_empate(puntaje);

    mostrar_resultado_final(puntaje, turno_actual);

    cerrar_archivo(archivo);

    return 0;
}
