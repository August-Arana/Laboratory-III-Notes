#ifndef PANEL_H
#define PANEL_H

void imprimir_uso(void);

int main(int argc, char *argv[]);

#endif
