#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "defs.h"
#include "archivos.h"
#include "consola.h"
#include "semaforos.h"
#include "super_derivador.h"


void mostrar_menu(void) {
    limpiar_pantalla();
    printf("*** SUPER DERIVADOR ***\n");
    printf("1. Iniciar cajero\n");
    printf("0. Salir\n");
    printf("*** SUPER DERIVADOR ***\n");
}

int menu_principal(void) {
    mostrar_menu();
    return pedir_entero("Ingrese una opcion: ");
}

void ingresar_producto(t_producto *producto) {
    char *descripcion;

    producto->precio = pedir_float("Ingrese el precio del producto: ");
    descripcion = pedir_string("Ingrese la descripcion del producto: ");
    strcpy(producto->descripcion, descripcion);
    free(descripcion);
}

int main(int argc, char *argv[]) {
    FILE *archivo;
    char archivo_nombre[BUFFER_SIZE];
    int semaforos[CANTIDAD_CAJEROS];
    int id_cajero, i, opcion, cantidad;
    t_producto productos[PRODUCTOS_MAXIMO];
    char linea[BUFFER_SIZE];

    for (i = 0; i < CANTIDAD_CAJEROS; i++) {
        sprintf(archivo_nombre, "cajero%d.dat", i);
        archivo = abrir_archivo(archivo_nombre, "w+");
        semaforos[i] = crear_semaforo(CLAVE_IPC, archivo_nombre);
        inicializar_semaforo(semaforos[i], VERDE);
        cerrar_archivo(archivo);
    }

    opcion = menu_principal();
    while (opcion) {
        /* Pedimos los productos al usuario */
        cantidad = 0;
        do {
            ingresar_producto(&productos[cantidad++]);
        } while(pedir_si_o_no("Agregar otro producto? (s/n): "));

        /* Determinar cajero en base a la cantidad de productos */
        if (cantidad <= CAJA_1_MAXIMO) {
            id_cajero = 0;
        } else if (cantidad <= CAJA_2_MAXIMO) {
            id_cajero = 1;
        } else {
            id_cajero = 2;
        }

        esperar_semaforo(semaforos[id_cajero]);
        sprintf(archivo_nombre, "cajero%d.dat", id_cajero);

        archivo = abrir_archivo(archivo_nombre, "w");
        for (i = 0; i < cantidad; i++) {
            sprintf(linea, "%s\t%02f", productos[i].descripcion, productos[i].precio);
            escribir_linea(archivo, linea);
        }
        cerrar_archivo(archivo);

        levantar_semaforo(semaforos[id_cajero]);

        opcion = menu_principal();
    }

    return 0;
}
