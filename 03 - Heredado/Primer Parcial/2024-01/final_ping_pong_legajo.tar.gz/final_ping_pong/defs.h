#ifndef DEFS_H
#define DEFS_H

#ifndef NULL
#define NULL 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define ARCHIVO_SIZE 50000
#define BUFFER_SIZE 100
#define TURNOS_SIZE 50

#define EQUIPOS_SIZE 2

#define ROJO 0
#define VERDE 1

#define ARCHIVO "partido.dat"
#define CLAVE_IPC 40

#define INTERVALO_PRODUCTOR_DESDE 100
#define INTERVALO_PRODUCTOR_HASTA 1000
#define INTERVALO_CONSUMIDOR 500

#endif
