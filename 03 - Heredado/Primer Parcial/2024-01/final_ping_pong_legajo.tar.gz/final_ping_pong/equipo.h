#ifndef KARTING_H
#define KARTING_H

void imprimir_uso(void);
int inicializar_configuracion(int argc, char *argv[]);
int verificar_partido_finalizado(char *contenido_archivo);
int verificar_turno_de_escribir(char *contenido_archivo, int id_karting, int turno_actual);
int main(int argc, char *argv[]);

#endif
