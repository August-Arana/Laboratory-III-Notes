#ifndef CLAVES_IPC_H
#define CLAVES_IPC_H

#include <sys/types.h>

/**
 * Crea uan clave de un archivo y un numero
 * @param ruta Ruta al archivo
 * @param id Identificador
 * @return Clave IPC
 */
key_t crear_clave_ipc(char *ruta, int id);


#endif
