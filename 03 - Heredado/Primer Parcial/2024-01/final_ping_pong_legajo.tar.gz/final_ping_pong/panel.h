#ifndef PANEL_H
#define PANEL_H

void imprimir_uso(void);
int inicializar_configuracion(int argc, char *argv[]);
char *buscar_turno_actual(char *contenido, int turno_actual);
int verificar_escribieron_equipos(char *contenido);
void parsear_jugadas(char *contenido, int *metros);
void mostrar_estado_partido(int *puntaje, int *jugada_actual, int turno_actual);
void ganador_aleatorio_en_empate(int *puntaje);
void mostrar_resultado_final(int *metros_totales, int turno_actual);

int main(int argc, char *argv[]);

#endif
