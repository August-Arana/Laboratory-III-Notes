#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "defs.h"
#include "archivos.h"
#include "semaforos.h"
#include "panel.h"

void imprimir_uso(void) {
    printf("Usage: ./caja id_caja\n");
    printf("id_caja: 1, 2 o 3\n");
}

int inicializar_configuracion(int argc, char *argv[]) {
    int id;
    /* Verificar parametros de entrada */
    if (argc != 2) {
        imprimir_uso();
        exit(-1);
    } else {
        id = atoi(argv[1]);
        if (id < 1 || id > 3) {
            imprimir_uso();
            exit(-2);
        }
    }

    return id;
}

int main(int argc, char *argv[]) {
    FILE *archivo;
    char archivo_nombre[BUFFER_SIZE];
    int semaforo;
    int id_cajero;
    char linea[BUFFER_SIZE];
    t_producto producto;
    int cantidad;
    float total;

    id_cajero = inicializar_configuracion(argc, argv);

    sprintf(archivo_nombre, "cajero%d.dat", id_cajero - 1);
    semaforo = crear_semaforo(CLAVE_IPC, archivo_nombre);

    while (TRUE) {
        esperar_semaforo(semaforo);

        archivo = abrir_archivo(archivo_nombre, "r");
        if (archivo && !es_fin_de_archivo(archivo)) {
            cantidad = total = 0;
            /* Leer el archivo linea a linea */
            while(leer_linea(archivo, linea, BUFFER_SIZE)) {
                sscanf(linea, "%s\t%02f", producto.descripcion, &producto.precio);
                printf("Producto: %s - Precio: %.2f\n", producto.descripcion, producto.precio);
                cantidad++;
                total += producto.precio;
            }
            cerrar_archivo(archivo);
            eliminar_archivo(archivo_nombre);

            /* Informar el total */
            if (cantidad > 0) {
                printf("El cliente debe abonar un total de %.2f por %d productos\n\n", total, cantidad);
            }
        }

        levantar_semaforo(semaforo);
    }

    return 0;
}
