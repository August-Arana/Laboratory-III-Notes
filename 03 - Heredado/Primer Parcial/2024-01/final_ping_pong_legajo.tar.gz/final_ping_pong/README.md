# Instrucciones

1. Compilar
   ```bash
   make
   ```

3. Ejecutar primero el panel, donde puntaje_maximo es el maximo del puntaje para finalizar un partido:
   ```bash
   ./panel puntaje_maximo
   ```

3. Ejecutar los equipos en cualquier orden, Argentina es el id 1 y japón es el id 2.
   ```bash
   ./equipo 1
   ./equipo 2
   ```