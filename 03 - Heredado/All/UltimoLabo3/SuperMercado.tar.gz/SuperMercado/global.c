#include "pthread.h"
#include "semaforo.h"

pthread_mutex_t mutex;
int TotalCaja0;
int TotalCaja1;
int TotalCaja2;



