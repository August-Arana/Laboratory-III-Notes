

1-Para su ejecucion completa es necesario abrir 2 terminales

2- se recomiendo el uso del comando sudo su en cada terminal antes de ejecutar los comandos que copilaran y correran el programa

3- El codigo a la hora de ejecutar el make crea 2 archivos ejecutables
Uno de nombre "Derivador" y otro de nombre "Cajas"



2- los dos "main" son Derivador.c y creadorhilos.c

3- El Orden de ejecucion para el correcto funcionamiento es
       ./Cajas
       ./Derivador



