#ifndef _HILOS
#define _HILOS

void *hilos(void *parametro);

#endif
