

1-Para su ejecucion completa es necesario abrir 2 terminales

2- se recomiendo el uso del comando sudo su en cada terminal antes de ejecutar los comandos que copilaran y correran el programa

3- El codigo a la hora de ejecutar el make crea 2 archivos ejecutables
Uno de nombre "panel" y otro de nombre "corredores"



2- los dos "main" son PanelCarrera.c y creadorhilos.c

3- Es indiferente el orden de ejecucion
       ./Panel
       ./Corredores



