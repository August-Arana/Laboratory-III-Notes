#include "pthread.h"
#include "semaforo.h"

pthread_mutex_t mutex;
int vueltasPerro;
int vueltasGato;
int vueltasConejo;


