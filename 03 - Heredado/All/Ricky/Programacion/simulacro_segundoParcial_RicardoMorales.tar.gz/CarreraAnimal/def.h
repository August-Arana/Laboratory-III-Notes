#ifndef _DEF
#define _DEF

#define TRUE 1
#define FALSE 0
#define DESDE 29
#define HASTA 54
#define CANTIDAD 10
#define LARGO 100

#define ROJO 0
#define VERDE 1
#define CLAVE_BASE 34

#define TIEMPO_ESPERA 500000

#define CANTIDAD_CORREDORES 3

#endif

