#include <pthread.h> 
#include "semaforo.h"

pthread_mutex_t mutex;
int vueltasPerro = 0;
int vueltasGato = 0;
int vueltasConejo = 0;


