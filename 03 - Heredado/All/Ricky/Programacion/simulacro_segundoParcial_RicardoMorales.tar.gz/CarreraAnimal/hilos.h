#ifndef THREADANIAMALES_
#define THREADANIMALES_

void *hilos(void *parametro);

#endif
