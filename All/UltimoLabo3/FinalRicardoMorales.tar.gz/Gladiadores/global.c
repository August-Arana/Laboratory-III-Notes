#include "pthread.h"
#include "semaforo.h"

pthread_mutex_t mutex;
int puntaje0;
int puntaje1;
int puntaje2;
int tiros;
int finalizado;
int Cantidad_Jugadores ;


