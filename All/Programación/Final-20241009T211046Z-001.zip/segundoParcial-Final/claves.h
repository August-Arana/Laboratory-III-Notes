#ifndef _CLAVES
#define _CLAVEs
#include <sys/ipc.h>
key_t creo_clave(int r_clave);


#endif
