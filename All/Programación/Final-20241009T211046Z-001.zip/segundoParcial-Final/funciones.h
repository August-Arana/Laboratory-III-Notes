#ifndef _FUNCIONES
#define _FUNCIONES

int inDevolverAleatorio(int inDesde,int inHasta);
int *inDevolverAleatorioNoRepetido(int inDesde,int inHasta,int inCantidadAleatorios);
void mostrarArreglo(int arreglo[10],int longitudArreglo);

#endif
